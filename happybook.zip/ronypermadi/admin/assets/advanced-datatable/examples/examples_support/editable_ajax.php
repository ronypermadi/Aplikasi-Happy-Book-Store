<?php
	echo $_POST['value'].' (server updated)';
?>